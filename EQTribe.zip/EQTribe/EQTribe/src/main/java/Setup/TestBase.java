package Setup;

import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase {
	public static WebDriver driver;

	public void SetUpbrowser() throws Exception {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\ABHIJIT\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	}

	public void teardowngen() {
		driver.close();
		driver.quit();
	}

	public static void Screenshot(String i) throws Exception {	
		File Screenshot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Screenshot, new File("C:\\Users\\ABHIJIT\\Downloads\\Screenshot\\"+i+".png"));	
	}
}