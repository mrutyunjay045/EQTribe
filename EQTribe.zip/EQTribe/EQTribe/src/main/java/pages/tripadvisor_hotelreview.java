package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Setup.TestBase;

public class tripadvisor_hotelreview extends TestBase{

	WebElement e;
	public tripadvisor_hotelreview() {
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//input[@name='ReviewTitle']")
	WebElement review_title;

	@FindBy(xpath="//textarea[@name='ReviewText']")
	WebElement review_text;
	
	@FindBy(xpath="//span[@id='bubble_rating']")
	WebElement rating;

	@FindBy(xpath="//div[text()='Business']")
	WebElement sort_of_trip;

	@FindBy(xpath="//select[@name='trip_date_month_year']")
	WebElement date;

	@FindBy(xpath="//input[@type='checkbox']")
	WebElement checkbox;

	@FindBy(xpath="//div[@id='SUBMIT']")
	WebElement submit;

	@FindBy(xpath="//iframe[@id='overlayRegFrame']")
	WebElement iframe;

	@FindBy(xpath="//span[@class='textContainer' and text()='Continue with Google ']")
	WebElement testcomplete;

	public WebElement review_title_field()  {
		e= review_title;
		return e;
	}

	public WebElement review_text_field()  {
		e= review_text;
		return e;
	}

	public WebElement rating_field()  {
		e= rating;
		return e;
	}

	public WebElement sort_of_trip_field()  {
		e= sort_of_trip;
		return e;
	}

	public WebElement date()  {
		e= date;
		return e;
	}

	public WebElement checkbox()  {
		e= checkbox;
		return e;
	}

	public WebElement submit_field()  {
		e= submit;
		return e;
	}

	public WebElement iframe()  {
		e= iframe;
		return e;
	}

	public WebElement testcomplete()  {
		e= testcomplete;
		return e;
	}

}