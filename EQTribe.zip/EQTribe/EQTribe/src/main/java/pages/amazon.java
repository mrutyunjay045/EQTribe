package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Setup.TestBase;

public class amazon extends TestBase {
	WebElement e;
	public amazon() {
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//input[@name='field-keywords']")
	WebElement searchField;

	@FindBy(xpath="//input[@class='nav-input' and @type='submit']")
	WebElement searchButton;

	public WebElement searchField()  {
		e= searchField;
		return e;
	}

	public WebElement searchButton()  {
		e= searchButton;
		return e;
	}

	public WebElement getamazonprice(String MobileModel) {
		System.out.println("Selecting Mobile Model : " +MobileModel);
		e= driver.findElement(By.xpath("((//span[text()='"+MobileModel +"']//following::span[@data-a-color='price'])[1]//following::span[@class='a-price-whole'])[1]"));
		return e;
	}
}
