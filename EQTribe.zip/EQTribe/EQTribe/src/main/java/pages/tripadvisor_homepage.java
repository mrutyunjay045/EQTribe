package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Setup.TestBase;

public class tripadvisor_homepage extends TestBase {

	WebElement e;
	public tripadvisor_homepage() {
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//div[@title='Search']")
	WebElement search;

	@FindBy(xpath="//input[@id='mainSearch']")
	WebElement inputfield;

	@FindBy(xpath="//div[@id='SEARCH_BUTTON_CONTENT']")
	WebElement search_button;	

	@FindBy(xpath="(//input[@title='Search'])[last()]")
	WebElement searchField;

	@FindBy(xpath="//span[text()='Search']")
	WebElement Search1;
	
	public WebElement Search1()  {
		e= Search1;
		return e;
	}
	
	public WebElement search()  {
		e= search;
		return e;
	}

	public WebElement inputfield()  {
		e= inputfield;
		return e;
	}
	public WebElement search_button()  {
		e= search_button;
		return e;
	}
	public WebElement searchField()  {
		e= searchField;
		return e;
	}

	public WebElement SearchResult(String SearchKey)  {
		e= driver.findElement(By.xpath("((//div[@class='ui_column is-12 srp_result_sections']//following::div[@class='result-title'])//span[contains(text(),'"+SearchKey+"')])[1]"));
		return e;
	}

}