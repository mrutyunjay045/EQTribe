package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Setup.TestBase;

public class tripadvisor_hoteldetails extends TestBase {

	WebElement e;
	public tripadvisor_hoteldetails() {
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//div[@class='was-ssr-only']/div[@id='REVIEWS']")
	WebElement scroll;

	@FindBy(xpath="//a[text()='Write a review']")
	WebElement write_review;

	public WebElement scroll()  {
		e= scroll;
		return e;
	}

	public WebElement write_review_field()  {
		e= write_review;
		return e;
	}

}