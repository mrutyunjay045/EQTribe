package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Setup.TestBase;

public class flipkart extends TestBase{

	WebElement e;
	public flipkart() {
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//input[@name='q']")
	WebElement searchField;

	@FindBy(xpath="//button[@type='submit']")
	WebElement searchButton;

	public WebElement searchField()  {
		e= searchField;
		return e;
	}

	public WebElement searchButton()  {
		e= searchButton;
		return e;
	}

	public WebElement getflipkartprice(String MobileModel) {
		String model_sub = MobileModel.substring(0, 16).toString();
		String colour[] =MobileModel.split("- ",2);
		String Gb = MobileModel.substring(17, 19);
		System.out.println("Selecting Mobile Model : " +MobileModel);
		e= driver.findElement(By.xpath("(//div[contains(text(),'"+ model_sub+"("+colour[1]+"')]/../*//ul/li[contains(text(),'"+Gb+"')]//ancestor::div[1]//../following::div//div//div//div)[1]"));
		return e;
	}
}