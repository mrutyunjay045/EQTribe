package testcase;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Setup.TestBase;
import pages.amazon;
import pages.flipkart;
import pages.tripadvisor_homepage;
import pages.tripadvisor_hoteldetails;
import pages.tripadvisor_hotelreview;

public class Assignment extends TestBase {

	@BeforeMethod
	public void WebDriverSetUp() throws Exception {
		System.out.println("Setting up the browser");
		SetUpbrowser();
	}

	@Test
	public void assignment1() throws Exception {
		System.out.println("Loading configuration.properties file");
		FileReader reader = new FileReader("C:\\Users\\ABHIJIT\\eclipse-workspace\\EQTribe-20200204T163647Z-001.zip_expanded\\EQTribe\\EQTribe\\src\\main\\java\\config.properties");
		Properties p = new Properties();
		p.load(reader);
		String MobileModel = p.getProperty("MobileName");
		System.out.println("Executing Assignment 1");
		System.out.println("Opening Amazon Website");
		driver.get("https://www.amazon.in");
		Thread.sleep(10000);
		amazon amazonObj = new amazon();
		amazonObj.searchField().sendKeys(MobileModel);
		amazonObj.searchButton().click();
		Thread.sleep(10000);
		String amazonprice = (amazonObj.getamazonprice(MobileModel).getText()).replace(",", "");
		int amazonpriceAmount = Integer.parseInt(amazonprice);
		Screenshot("Amazon Product Price");
		System.out.println("amazonprice " + amazonpriceAmount);

		System.out.println("Opening Flipkart Website");
		driver.get("https://www.flipkart.com/");
		Thread.sleep(10000);
		driver.findElement(By.xpath("//html//body")).sendKeys(Keys.ESCAPE);
		Thread.sleep(5000);
		flipkart flipkartObj = new flipkart();
		flipkartObj.searchField().sendKeys(MobileModel);
		Thread.sleep(5000);
		flipkartObj.searchButton().click();
		Thread.sleep(10000);
		String flipkartprice = (flipkartObj.getflipkartprice(MobileModel).getText()).replace(",", "").replace("₹", "");
		System.out.println("flipKart Price Amount " + flipkartprice);
		int flipkartPriceAmount = Integer.parseInt(flipkartprice);
		System.out.println("Comparing both the prices");
		if (flipkartPriceAmount > amazonpriceAmount) {
			System.out.println("Flipkart costly "+ flipkartPriceAmount);
		} else {
			System.out.println("Amazon costly "+ amazonpriceAmount);
		}
		System.out.println("Assignment 1 successfully completed");
		Screenshot("Flipkart Product Price");
	}

	@Test
	public void assignment2() throws Exception {
		System.out.println("Executing assignment 2");
		driver.manage().deleteAllCookies();
		System.out.println("Launching tripadvisor");
		driver.get("https://www.tripadvisor.in/");
		Thread.sleep(3000);
		System.out.println("Loading configuration.properties file");
		FileReader reader = new FileReader("C:\\\\Users\\\\ABHIJIT\\\\eclipse-workspace\\\\EQTribe-20200204T163647Z-001.zip_expanded\\\\EQTribe\\\\EQTribe\\\\src\\\\main\\\\java\\\\config.properties");
		Properties p = new Properties();
		p.load(reader);
		String hotel = p.getProperty("HotelName");
		System.out.println("Searching for hotel "+ hotel );
		tripadvisor_homepage tripadvisor_homepage_Obj = new tripadvisor_homepage();
		List<WebElement> a =driver.findElements(By.xpath("//span[text()='Search']"));
		if(a.size()!=0) {

			tripadvisor_homepage_Obj.Search1().click();
			Thread.sleep(4000);
			tripadvisor_homepage_Obj.inputfield().sendKeys(p.getProperty("HotelName"));
			tripadvisor_homepage_Obj.inputfield().sendKeys(Keys.ENTER);
		}
		else {
			tripadvisor_homepage_Obj.searchField().click();
			tripadvisor_homepage_Obj.searchField().sendKeys(p.getProperty("HotelName"));
			tripadvisor_homepage_Obj.searchField().sendKeys(Keys.ENTER);
		}
		
		Thread.sleep(4000);
		Screenshot("Hotel Search Results");
		tripadvisor_homepage_Obj.SearchResult(hotel).click();
		Thread.sleep(10000);
		System.out.println("Select the hotel "+hotel+" from search results");
		Screenshot("Selected mentioned hotel");
		tripadvisor_hoteldetails tripadvisor_hoteldetails_Obj = new tripadvisor_hoteldetails();
		ArrayList<String> tripadvisor_hoteldetails_tab = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tripadvisor_hoteldetails_tab.get(1));
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", tripadvisor_hoteldetails_Obj.scroll());
		Thread.sleep(10000);
		System.out.println("Enter Review comments");
		tripadvisor_hoteldetails_Obj.write_review_field().click();
		Thread.sleep(10000);
		Screenshot("Review Page");
		tripadvisor_hotelreview tripadvisor_hotelreview_Obj = new tripadvisor_hotelreview();
		ArrayList<String> tripadvisor_hotelreview_tab = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tripadvisor_hotelreview_tab.get(2));
		Thread.sleep(5000);
		tripadvisor_hotelreview_Obj.rating_field().click();
		Thread.sleep(2000);
		tripadvisor_hotelreview_Obj.review_title_field().sendKeys(p.getProperty("ReviewTitle"));
		Thread.sleep(2000);
		tripadvisor_hotelreview_Obj.review_text_field().sendKeys(p.getProperty("ReviewText"));
		Thread.sleep(2000);
		tripadvisor_hotelreview_Obj.sort_of_trip_field().click();
		Thread.sleep(2000);
		Select date = new Select(tripadvisor_hotelreview_Obj.date());
		date.selectByVisibleText(p.getProperty("Date"));
		Thread.sleep(2000);
		js.executeScript("arguments[0].scrollIntoView();", tripadvisor_hotelreview_Obj.submit_field());
		Thread.sleep(3000);
		tripadvisor_hotelreview_Obj.checkbox().click();
		Thread.sleep(1000);
		tripadvisor_hotelreview_Obj.submit_field().click();
		Thread.sleep(5000);
		System.out.println("Submit the review");
		Screenshot("Review Submitted");
		driver.switchTo().frame(tripadvisor_hotelreview_Obj.iframe());
		if (tripadvisor_hotelreview_Obj.testcomplete().isDisplayed()) {
			System.out.println("Assignment 2 successfully completed");
		}
	}

	@AfterMethod
	public void teardown() {
		teardowngen();
	}
}